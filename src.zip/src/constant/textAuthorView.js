export const textAuthor = {
    ALL: 'ALL',
    ALONE: 'ALONE'
}