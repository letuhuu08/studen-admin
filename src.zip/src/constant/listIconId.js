export const listIdIcon = [
  "building",
  "bus",
  "education",
  "parking",
  "gas-station",
  "bank",
  "hospital",
  "sport",
  "restaurant",
  "supermarket",
  "police",
];
